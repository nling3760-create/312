import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const lifeProfiles = sqliteTable('life_profiles', {
  ownerId: text('owner_id').notNull(),
  nicknameKey: text('nickname_key').notNull(),
  nickname: text('nickname').notNull(),
  verifier: text('verifier').notNull(),
  data: text('data').notNull(),
  revision: integer('revision').notNull().default(0),
  updatedAt: text('updated_at').notNull(),
}, table => [primaryKey({ columns: [table.ownerId, table.nicknameKey] })]);
