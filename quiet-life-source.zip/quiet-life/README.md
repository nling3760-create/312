# 日常 · 个人生活记录

A mobile-first Chinese life journal with weight trends, meals and photographs, exercise, sleep, body measurements, budgets and transactions.

## Hosted version

The existing Sites URL retains its owner-only access policy. This release adds a real D1 database and R2 photo storage. Visitors use the same ChatGPT account, nickname and sync passphrase on each device. Nickname matching never grants access to an unrelated account. The sync passphrase is derived with PBKDF2-SHA256 (210,000 iterations) in the browser; only a one-way verifier is stored in D1. The reusable proof is remembered on that device, so use trusted devices. A lost passphrase cannot currently be recovered; JSON backups remain available.

First visit prompts for a nickname. Existing nickname + correct passphrase restores cloud data. A new nickname requires confirmation before creating a new cloud profile and uploading the existing local records. Before switching, pending records must sync. A pre-connect local copy is retained under `quiet-life-before-connect`, and per-nickname cached records under `quiet-life-cache:<nickname>`.

All formerly unconfigured AI buttons, settings and network adapters have been removed. Daily and weekly reminders are explicitly calculated locally. Photographs remain a journal feature; calories and nutrition are manually editable estimates.

## Data and conflict handling

`public/core.js` owns calculations and photo caching. `public/sync.js` owns nickname connection and synchronization. `lib/cloud-api.js` handles authenticated data and private photo requests. `db/schema.ts` and versioned SQL in `drizzle/` own the schema.

Records save locally first. A persistent per-record operation queue is retried on online events, returning to the page and a 30-second visible-page poll. Cloud updates use revision-checked compare-and-swap. Conflicts rebase only outstanding local operations onto the latest cloud data. Deleted records are not resurrected by unrelated offline edits. Concurrent edits to the same record use the later synchronized operation. Weight and sleep dates are deduplicated; budgets are deduplicated by period and type. Local pending edits remain visible if syncing fails.

Photos are compressed to a maximum edge of 1200 px, kept in IndexedDB and uploaded to a nickname-scoped private R2 path. Other devices download them on demand. Full JSON backup fetches referenced photos before exporting. CSV contains all record types in a UTF-8 unified table. No actual user records are committed to this repository.

## Run and test

Node >=22.13 is required. Follow the maintained Sites helpers for installation, building and deployment. `npm test` checks calendar arithmetic, true averages, budgets, measurement reminders, SQLite persistence, authorization, password mismatch, two-device conflicts, deletion propagation and photo storage. `npm run build` produces the Worker artifact. `npm run db:generate` creates an appended migration after schema changes. Hosted migrations are applied during deployment.

The managed preview intentionally does not simulate ChatGPT sign-in. A preview without identity cannot read cloud data; the production private site receives identity from Sites dispatch. Local test fixtures use a separate in-memory SQLite database and synthetic data only.

## GitHub and domestic hosting

This full-stack source can be versioned on GitHub. GitHub Pages alone cannot run the database/photo API, and the current owner-private Sites backend must not be made public merely for a mirror. A GitHub Pages deployment therefore requires a separately hosted authenticated backend and an explicit deployment configuration; an unconnected mirror is not presented as completed.

For reliable domestic access, deploy the frontend and authenticated API to a service that is actually reachable on the intended domestic networks, using a suitable domain, HTTPS and persistent database/object storage. Hosting on GitHub alone is not a guarantee of domestic availability. The current code has no external font, CDN, analytics or AI dependency.

## Limitations

The app cannot send guaranteed notifications while closed. Offline records require an initial successful page load; a full offline PWA is not claimed. Sync is eventually consistent, with explicit version protection. Cloud storage does not replace downloadable backups. Clinical diagnosis and precise calorie measurement are outside the app's purpose.
