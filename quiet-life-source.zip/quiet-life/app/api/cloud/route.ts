import { env } from 'cloudflare:workers';
import { cloudAPI } from '../../../lib/cloud-api.js';
export const dynamic = 'force-dynamic';
export async function POST(request: Request) { return cloudAPI(request,env); }
