CREATE TABLE `life_profiles` (
	`owner_id` text NOT NULL,
	`nickname_key` text NOT NULL,
	`nickname` text NOT NULL,
	`verifier` text NOT NULL,
	`data` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`owner_id`, `nickname_key`)
);
